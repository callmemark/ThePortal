<?php echo $__env->make('components/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class='container'>
	<div class='row'>
		<div class='col-md-12'>
			<p class='heading-title'>Grades</p>
			<table class='my-table'>
				<tr>
					<td>Subject</td>
					<td>Unit</td>
					<td>Grade</td>
				</tr>

				<?php $__currentLoopData = $enrolled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr class='lift soft-corner'>
					<td><?php echo e($subject_data -> subject); ?></td>
					<td><?php echo e($subject_data -> unit); ?></td>
					<td><?php echo e($subject_data -> grade); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
	</div>
</div>

<?php echo $__env->make('components/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mark\Documents\LaravelDevEnv\ThePortal\resources\views/student-grade-view.blade.php ENDPATH**/ ?>