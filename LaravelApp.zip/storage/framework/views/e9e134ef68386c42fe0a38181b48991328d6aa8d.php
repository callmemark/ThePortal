<?php echo $__env->make('components/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<style>
	#subject-table{
		margin-top: 1rem;
	}
</style>

<div class='container'>
	<div class='row'>
		<div class='col-md-12'>
			<p class='heading-title'>Subjects Manager</p>
		</div>
	</div>

	<div class='row'>
		<div class='col-md-12 lift cardify'>
			<h4 class='mt-5 mb-2'>Add Subjects</h4>
			<form action=<?php echo e(Route('subject.create')); ?> method='post'>
				<?php echo csrf_field(); ?>
				<?php echo method_field('post'); ?>

				<label class='form-label'>Add Subject</label>
				<input class='form-control' type="text" name='subject' required>

				<label class='form-label'>Unit</label>
				<input class='form-control' type='number' name='unit' required>

				<?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<p class='error'>$err</p>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<?php if(session() -> has('error')): ?>
					<p class='error'><?php echo e(session() -> get('error')); ?></p>
				<?php endif; ?>

				<?php if(session() -> has('success')): ?>
					<p class='success'><?php echo e(session() -> get('success')); ?></p>
				<?php endif; ?>

				<button class='btn btn-themed mt-2' type='submit'>Add New Subject</button>
			</form>
		</div>
	</div>

	<div class='row'>
		<div class='col-md-12'>
			<p class='heading-secondary'>Subject List</p>
			<table class='my-table' id='subject-table'>
				<tr>
					<th>Subject</th>
					<th>Unit</th>
					<th>Edit</th>
					<th>Delete</th>
				</tr>
				<?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class='lift'>
						<td><?php echo e($subject -> subject); ?></td>
						<td><?php echo e($subject -> unit); ?></td>
						<td>
							<form action=<?php echo e(route('subject.edit', ['subject' => $subject])); ?> method='get'>
								<?php echo csrf_field(); ?>
								<?php echo method_field('get'); ?>
								<button class='btn btn-themed'>Edit</button>
							</form>
						</td>
						<td>
							<button class='btn btn-danger' data-bs-toggle="modal" data-bs-target="#delete-modal">Delete</button>
							<form action=<?php echo e(route('subject.delete', ['subject' => $subject])); ?> method='post'>
								<?php echo csrf_field(); ?>
								<?php echo method_field('post'); ?>

								<?php echo $__env->make('components/confirmation-modal', 
									[	'modal_id' => 'delete-modal',
										'title' => 'Delete Data',
										'message' => 'This action cannot be undone'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							</form>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
	</div>
</div>


<?php echo $__env->make('components/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mark\Documents\LaravelDevEnv\ThePortal\resources\views/subject-manager.blade.php ENDPATH**/ ?>