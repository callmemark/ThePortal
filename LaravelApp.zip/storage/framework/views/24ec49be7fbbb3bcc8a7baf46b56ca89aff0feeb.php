<?php echo $__env->make('components/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
	#submit-btn{
		padding: 0.5rem 5rem;
		margin-top: 2ren;
	}

	.error{
		font-weight: bold;
		color: red;
	}
</style>

<div class='container'>
	<div class='row'>
		<div class='col-md-12'>
			<p class='heading-title'>Student Registration</p>

			<?php if($errors -> any()): ?>
				<?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<p class='error'><?php echo e($err); ?></p>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>

			<?php if(session() -> has('success')): ?>
				<h5 class='success'><?php echo e(session('success')); ?></h5>
			<?php endif; ?>

			<?php if(session() -> has('error')): ?>
				<h5 class='error'><?php echo e(session('error')); ?></h5>
			<?php endif; ?>

			<form action=<?php echo e(route('student.create')); ?> method='post'>
				<?php echo csrf_field(); ?>
				<?php echo method_field('post'); ?>

				<label class='form-label'>First Name</label>
				<input class='form-control' type='text' name='firstname'>

				<label class='form-label'>Middle Name</label>
				<input class='form-control' type='text' name='middlename'>

				<label class='form-label'>Last Name</label>
				<input class='form-control' type='text' name='lastname'>

				<label class='form-label'>Age</label>
				<input class='form-control' type='number' name='age'>

				<h4 class='mt-3'>Gender</h4>
				<select class="form-select" aria-label="Gender" name='gender'>
					<option selected>Male</option>
					<option value="Female">Female</option>
				</select>
				
				<button type='submit' class='btn btn-themed mt-3'>Register</button>
			</form>
		</div>
	</div>
</div>


<?php echo $__env->make('components/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mark\Documents\LaravelDevEnv\ThePortal\resources\views/student-register.blade.php ENDPATH**/ ?>