<?php echo $__env->make('components/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('themes/theme-initializer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<style type="text/css">
	#page-title{
		text-align: center;
		font-size: 5rem;
	}
</style>


<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<p id="page-title">THE PORTAL</p>
		</div>
	</div>
	<div class="row">
		<div class="col-md-3 d-flex flex-row align-items-center justify-content-center">
			<div class="theme-cardify">
				<p>Admin Account</p>
				<div class="card-cover-image">
					
				</div>
				<form action=<?php echo e(route('login.admim.create')); ?> method="get">
					<?php echo csrf_field(); ?> 
					<?php echo method_field('get'); ?>
					
					<button class="theme-btn theme-btn-primary">Login Page</button>
				</form>
			</div>	
		</div>

		<div class="col-md-3 d-flex flex-row align-items-center justify-content-center">
			<div class="theme-cardify">
				<p>Student Account</p>
				<div class="card-cover-image">
					
				</div>
				<form action=<?php echo e(route('student.login.create')); ?> method="get">
					<?php echo csrf_field(); ?> 
					<?php echo method_field('get'); ?>
					
					<button class="theme-btn theme-btn-primary">Login Page</button>
				</form>
			</div>	
		</div>

		<div class="col-md-3 d-flex flex-row align-items-center justify-content-center">
			<div class="theme-cardify">
				<p>Instructor Account</p>
				<div class="card-cover-image">
					
				</div>
				<form action=<?php echo e(route('instructor.login.create')); ?> method="get">
					<?php echo csrf_field(); ?> 
					<?php echo method_field('get'); ?>
					
					<button class="theme-btn theme-btn-primary">Login Page</button>
				</form>
			</div>	
		</div>

		<div class="col-md-3 d-flex flex-row align-items-center justify-content-center">
			<div class="theme-cardify">
				<p>Parent Account</p>
				<div class="card-cover-image">
					
				</div>
				<form action="#" method="get">
					<?php echo csrf_field(); ?> 
					<?php echo method_field('get'); ?>

					<button class="theme-btn theme-btn-primary">Login Page</button>
				</form>
			</div>	
		</div>
	</div>
</div>


<?php echo $__env->make('components/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mark\Documents\LaravelDevEnv\ThePortal\resources\views/landing-page.blade.php ENDPATH**/ ?>