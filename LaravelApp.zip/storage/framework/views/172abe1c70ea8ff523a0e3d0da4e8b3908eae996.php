<?php echo $__env->make('components/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class='container'>
	<div class='row'>
		<div class='col-md-12'>
			<p class='heading-title'>Edit Suject</p>

			<form action=<?php echo e(route('subject.update', ['subject' => $subject])); ?> method='post'>
				<?php echo csrf_field(); ?>
				<?php echo method_field('post'); ?>

				<label class='form-label'>Subject Name</label>
				<input type='text' name='subject' class='form-control' value=<?php echo e($subject -> subject); ?>>

				<label class='form-label'>Unit</label>
				<input type='text' name='unit' class='form-control' value=<?php echo e($subject -> unit); ?>>

				<button class='btn btn-themed mt-3' type='submit'>Update Subject</button>

			</form>
		</div>
	</div>
</div>


<?php echo $__env->make('components/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mark\Documents\LaravelDevEnv\ThePortal\resources\views/subject-edit.blade.php ENDPATH**/ ?>