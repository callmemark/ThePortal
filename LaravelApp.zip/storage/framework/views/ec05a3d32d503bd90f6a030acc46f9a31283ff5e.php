<?php echo $__env->make('components/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class='container'>
	<div class='row'>
		<div class='col-md-12'>

			<p class='heading-title'>Student List</p>
			<table class='my-table'>
				<tr>
					<th>Name</th>
					<th>Age</th>
					<th>Gender</th>
					<th>Edit</th>
				</tr>

				<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class='lift'>
						<td><?php echo e($student -> firstname); ?> <?php echo e($student -> middlename); ?> <?php echo e($student -> lastname); ?></td>
						<td><?php echo e($student -> age); ?></td>
						<td><?php echo e($student -> gender); ?></td>
						<td>
							<form action='<?php echo e(route('student.edit', ['student' => $student])); ?>' method='get'>
								<?php echo csrf_field(); ?>
								<?php echo method_field('get'); ?>
								<button class='btn btn-themed' type='submit'>Edit</button>
							</form>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>			
		</div>
	</div>
</div>

<?php echo $__env->make('components/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mark\Documents\LaravelDevEnv\ThePortal\resources\views/student-list.blade.php ENDPATH**/ ?>