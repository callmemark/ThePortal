
<?php $theme = "classic";?>

<?php if($theme == "classic"): ?>
	<?php echo $__env->make('themes/classic-theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>


<?php if($theme == "dark"): ?>
	<?php echo $__env->make('themes/dark-theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?><?php /**PATH C:\Users\mark\Documents\LaravelDevEnv\ThePortal\resources\views/themes/theme-initializer.blade.php ENDPATH**/ ?>