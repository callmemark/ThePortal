<?php echo $__env->make('components/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<style>
	.card{
		border: none;
	}
</style>

<div class='container'>

	<div class='row'>
		<div class='col-md-12'>
			<p class='heading-title'>Edit Student Data</p>
		</div>
	</div>

	<div class='row'>
		<div class='col-md-8'>
			<form action=<?php echo e(route('student.update', ['student' => $student])); ?> method='post'>
				<?php echo csrf_field(); ?>
				<?php echo method_field('post'); ?>

				<label class='form-label'>First Name</label>
				<input class='form-control' type='text' name='firstname' value=<?php echo e($student->firstname); ?>>

				<label class='form-label'>Middle Name</label>
				<input class='form-control' type='text' name='middlename' value=<?php echo e($student->middlename); ?>>

				<label class='form-label'>Last Name</label>
				<input class='form-control' type='text' name='lastname' value=<?php echo e($student->lastname); ?>>

				<label class='form-label'>Age</label>
				<input class='form-control' type='number' name='age' value=<?php echo e($student->age); ?>>

				<h4 class='mt-3'>Gender</h4>
				<select class="form-select" aria-label="Gender" name='gender' value=value=<?php echo e($student->gender); ?>>
					<?php if($student->gender == "Female"): ?>
						<option selected>Female</option>
						<option value="Female">Male</option>
					<?php endif; ?>

					<?php if($student->gender == "Male"): ?>
						<option selected>Male</option>
						<option value="Female">Female</option>
					<?php endif; ?>
					
				</select>
				
				<button type='submit' class='btn btn-themed mt-5'>Update Student Data</button>
			</form>
		</div>

		<div class='col-md-4'>

			<div class="card mt-5 lift">
			  <h5 class="card-header text-color-theme background-theme">Cannot Be Undone</h5>
			  <div class="card-body background-theme">
			    <form action=<?php echo e(route('student.delete', ['student' => $student])); ?> method='post'>
			    	<?php echo csrf_field(); ?>
			    	<?php echo method_field('post'); ?>
					<button type='submit' class='btn btn-danger'>Delete Student Registration</button>
				</form>
			  </div>
			</div>

			<div class="card mt-3 lift">
			  <h5 class="card-header background-theme text-color-theme">Enroll To Subjects</h5>
			  <div class="card-body background-theme">
			    <form action=<?php echo e(route('enrollement.create', ['student' => $student])); ?> method='post'>
			    	<?php echo csrf_field(); ?>
			    	<?php echo method_field('post'); ?>

			    	<select class="form-select" aria-label="Subjects" name='subject-selected'>
						<option selected>Select Subject</option>
						<?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value=<?php echo e($subject); ?>><?php echo e($subject->subject); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>

					<?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<p class='text-error'><?php echo e($err); ?></p>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					<?php if(session() -> has('error')): ?>
						<p class='text-error'><?php echo e(session()->get('error')); ?></p>
					<?php endif; ?>
					<button type='submit' class='btn btn-themed mt-3'>Enroll to selected subject</button>
				</form>
			  </div>
			</div>
		</div>
	</div>

	<div class='row'>
		<div class='col-md-12'>
			<p class='heading-secondary text-color-main'>Enrolled Subjects</p>
			<table class='my-table'>
				<tr>
					<th>Subject</th>
					<th>Grade</th>
					<th>Remove</th>
				</tr>
				<?php $__currentLoopData = $enrolled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subs_enrolled): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr class='lift'>
					<td><?php echo e($subs_enrolled -> subject); ?></td>
					<td><?php echo e($subs_enrolled -> grade); ?></td>
					<td>
						<form action=<?php echo e(route('student.unenroll', ['student' => $student, 'subjectid' => $subs_enrolled -> id])); ?> method='post'>
							<?php echo csrf_field(); ?>
							<?php echo method_field('post'); ?>
							<button class='btn btn-danger' tpe='submit'>Remove</button>
						</form>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
	</div>
</div>

<?php echo $__env->make('components/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mark\Documents\LaravelDevEnv\ThePortal\resources\views/student-edit.blade.php ENDPATH**/ ?>