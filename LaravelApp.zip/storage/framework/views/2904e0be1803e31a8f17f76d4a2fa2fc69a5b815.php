<?php echo $__env->make('components/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('themes/theme-initializer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="content-col">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<p class="theme-header-3">Admin Dashboard</p>
			</div>
		</div>
	</div>
</div>	


<?php echo $__env->make('components/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mark\Documents\LaravelDevEnv\ThePortal\resources\views/pages/dashboards/admin_dashboard.blade.php ENDPATH**/ ?>