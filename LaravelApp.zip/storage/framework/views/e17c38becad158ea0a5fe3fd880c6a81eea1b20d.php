<?php echo $__env->make('components/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('themes/theme-initializer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="container">
	<div class="row">
		<div class="col-md-12">
			<p class="theme-header-3">Student Login</p>
			<?php if($errors -> any()): ?>
				<div class="error-display">
					<h4>Error</h4>
					<?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<p><?php echo e($error); ?></p>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			<?php endif; ?>

			<?php if(session() -> has('error')): ?>
				<div class="error-display">
					<h4>Error</h4>
					<p><?php echo e(session('error')); ?></p>
				</div>
			<?php endif; ?>

			<div class="theme-cardify">
				<form action=<?php echo e(route('student.login.auth')); ?>  method="post">
					<?php echo csrf_field(); ?>
					<?php echo method_field('post'); ?>

					<label class="form-label"> Email </label>
					<input type="email" class="form-control" name="school_email" value="<?php echo e(old('school_email')); ?>" required>

					<label class="form-label"> Password </label>
					<input type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" required>

					<button type="submit" class="theme-btn theme-btn-primary">Login</button>
				</form>
			</div>
		</div>
	</div>
</div>


<?php echo $__env->make('components/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mark\Documents\LaravelDevEnv\ThePortal\resources\views/pages/student_login_page.blade.php ENDPATH**/ ?>