@include('components/header')
@include('themes/theme-initializer')
@include('components/sidebar')


<div class="content-col">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<p class="theme-header-3">Admin Dashboard</p>
			</div>
		</div>
	</div>
</div>	


@include('components/footer')